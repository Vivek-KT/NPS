<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\TenantModel;


class TenantController extends BaseController
{
    public function index()
    {
       
        return view('createTenant');

    }
    public function createtenant()
    {
        $data = [];

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'tenantname' => 'required|min_length[2]|max_length[50]|validateTenant[tenantname]',
            ];
            $errors = [                
                'tenantname' => [
                    'validateTenant' => "Tenant name is already exist",
                ],
            ];
            if (!$this->validate($rules, $errors)) {
                return view('createTenant', [
                    "validation" => $this->validator,
                ]);
            } else {
                $this->insertTenant($this->request->getPost());
                $this->createnewTenantDB($this->request->getPost());

                session()->setFlashdata('response',"Tenant Inserted Successfully");
                return redirect()->to(base_url('createtenant'));
            }
        }
        return view('createTenant');
    }
    public function insertTenant($postdata) 
    {
        $model = new TenantModel();
        $data = [
            "tenant_name" => $postdata['tenantname']
        ];
        $model->insertBatch([$data]);
    }
    public function createnewTenantDB($postdata)
    {
        $dbname = "nps_".$postdata['tenantname'];
        //new DB creation for Tenant details
        $db = db_connect();
        $db->query('CREATE DATABASE '.$dbname);
        $db->query('USE '.$dbname);

        //new Table creation for Tenant Details
        $nps_answer_table = "CREATE TABLE `nps_answers_details` (
            `answer_id` int(11) NOT NULL  AUTO_INCREMENT PRIMARY KEY,
            `answer_name` text NOT NULL,
            `description` text NOT NULL,
            `question_id` int(11) NOT NULL,
            `info_details` varchar(120) NOT NULL,
            `created_at` timestamp NOT NULL DEFAULT current_timestamp()
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
        $db->query($nps_answer_table);

        $nps_campign_details = "CREATE TABLE `nps_campign_details` (`id` int(11) NOT NULL,
            `category_id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `user_id` int(11) NOT NULL,
            `question_id` varchar(55) NOT NULL,
            `answer_id` varchar(55) NOT NULL,
            `created_at` timestamp NOT NULL DEFAULT current_timestamp()
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
        $db->query($nps_campign_details);

        $nps_external_contacts = "CREATE TABLE `nps_external_contacts` (
            `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `created_by` int(11) NOT NULL COMMENT 'User_id',
            `name` varchar(120) NOT NULL,
            `firstname` varchar(120) NOT NULL,
            `lastname` varchar(120) NOT NULL,
            `contact_details` text NOT NULL,
            `email_id` varchar(120) NOT NULL,
            `created_at` timestamp NOT NULL DEFAULT current_timestamp()
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
        $db->query($nps_external_contacts);

        $nps_login_user_info = "CREATE TABLE `nps_login_user_info` (
            `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `user_id` int(11) NOT NULL,
            `login_time` timestamp NOT NULL DEFAULT current_timestamp(),
            `logout_time` timestamp NOT NULL DEFAULT current_timestamp()
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
        $db->query($nps_login_user_info);

        $nps_question_details = "CREATE TABLE `nps_question_details` (
            `question_id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `question_name` text NOT NULL,
            `description` text NOT NULL,
            `info_details` varchar(120) NOT NULL,
            `user_id` int(11) NOT NULL,
            `created_at` timestamp NOT NULL DEFAULT current_timestamp()
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
        $db->query($nps_question_details);


        $nps_survey_details = "CREATE TABLE `nps_survey_details` (
            `campign_id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `user_id` int(11) NOT NULL,
            `campain_name` varchar(120) NOT NULL,
            `mail_sent_to` text NOT NULL,
            `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
        $db->query($nps_survey_details);

        $nps_survey_response = "CREATE TABLE `nps_survey_response` (
            `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `campign_id` int(11) NOT NULL,
            `user_id` int(11) NOT NULL,
            `question_id` int(11) NOT NULL,
            `answer_id` int(11) NOT NULL,
            `ip_details` varchar(120) NOT NULL,
            `created_at` timestamp NOT NULL DEFAULT current_timestamp()
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
        $db->query($nps_survey_response);

        $nps_users = "CREATE TABLE `nps_users` (
            `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `firstname` varchar(120) DEFAULT NULL,
            `lastname` varchar(55) NOT NULL,
            `username` varchar(120) DEFAULT NULL,
            `tenant_id` int(11) NOT NULL,
            `email` varchar(120) NOT NULL,
            `phone_no` varchar(120) NOT NULL,
            `role` enum('admin','user') NOT NULL,
            `password` varchar(240) NOT NULL,
            `status` enum('1','0') NOT NULL,
            `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
            `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
        $db->query($nps_users);
    }
}
