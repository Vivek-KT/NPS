<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\UserModel;

class AdminController extends BaseController
{
    public function __construct()
    {
        if (session()->get('role') != "admin") {
            echo 'Access denied';
            exit;
        }
    }
    public function index()
    {
        $model = new UserModel();

        $user = $model->where('email', session()->get('email'))
                    ->first();
        return view("admin/dashboard");
    }
}
